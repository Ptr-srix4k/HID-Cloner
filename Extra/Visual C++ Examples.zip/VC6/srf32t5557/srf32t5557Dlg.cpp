// srf32t5557Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "srf32t5557.h"
#include "srf32t5557Dlg.h"
#include "SRF32.H"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSrf32t5557Dlg dialog

CSrf32t5557Dlg::CSrf32t5557Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrf32t5557Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSrf32t5557Dlg)
	m_T5557_id = _T("");
	m_T5557 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrf32t5557Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSrf32t5557Dlg)
	DDX_Text(pDX, IDC_EDIT1, m_T5557_id);
	DDV_MaxChars(pDX, m_T5557_id, 16);
	DDX_Text(pDX, IDC_EDIT2, m_T5557);
	DDV_MaxChars(pDX, m_T5557, 56);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrf32t5557Dlg, CDialog)
	//{{AFX_MSG_MAP(CSrf32t5557Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrf32t5557Dlg message handlers

BOOL CSrf32t5557Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrf32t5557Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrf32t5557Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
HANDLE h_Dev = NULL;

void CSrf32t5557Dlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	if(s_test_dll(2012)!=2013)
	{
		return;
	}
	h_Dev = s_init(0,0,NULL,NULL);
	if (h_Dev == NULL)
	{
		return;
	}
	Sleep(100);
	if(s_test_device(h_Dev,2012)!=2013)
	{
		Sleep(50);
		s_bell(h_Dev,1);
		Sleep(100);
		s_bell(h_Dev,1);
		Sleep(100);
		s_bell(h_Dev,1);
		Sleep(100);
		s_exit(h_Dev);
		h_Dev = NULL;
		return;
	}
	s_bell(h_Dev,5);
}

void CSrf32t5557Dlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	s_exit(h_Dev);
	h_Dev = NULL;
}

void CSrf32t5557Dlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	s_bell(h_Dev,5);
}


void CSrf32t5557Dlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	unsigned char buff[256];
	__int16 nBytes = 0;
	nBytes = s_t5577_pageRead(h_Dev,0,1,buff);
	if((int)nBytes>0)
	{
		CString str="";
		for(int i=0;i<nBytes;i++)
		{
			str.Format(str+"%2.2X",buff[i]);
		}
		m_T5557_id = str;
		UpdateData(FALSE);
		s_bell(h_Dev,1);
		return;
	}
	m_T5557_id ="";
		UpdateData(FALSE);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
}

void CSrf32t5557Dlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
	unsigned char buff[256];
	__int16 nBytes = 0;
	nBytes = s_t5577_reset(h_Dev,0,buff);
	if((int)nBytes>0)
	{
		CString str="";
		for(int i=0;i<nBytes;i++)
		{
			str.Format(str+"%2.2X",buff[i]);
		}
		m_T5557 = str;
		UpdateData(FALSE);
		s_bell(h_Dev,1);
		return;
	}
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
}

void CSrf32t5557Dlg::OnButton6() 
{
	// TODO: Add your control notification handler code here
	unsigned char buff[256];
	__int16 nBytes = 0;
	m_T5557 = "";
	nBytes = s_t5577_read_current(h_Dev,0,buff);
	if((int)nBytes>0)
	{
		CString str="";
		for(int i=0;i<nBytes;i++)
		{
			str.Format(str+"%2.2X",buff[i]);
		}
		m_T5557 = str;
		UpdateData(FALSE);
		s_bell(h_Dev,1);
		return;
	}
	UpdateData(FALSE);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
}

void CSrf32t5557Dlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
	__int16 nBytes = 0;
	unsigned char databuff[256];
	databuff[0]=0x00;databuff[1]=0x08;databuff[2]=0x80;databuff[3]=0xe8;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,0,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 0 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,1,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 1 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,2,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 2 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,3,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 3 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,4,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 4 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,5,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 5 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}
	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,6,databuff);
	if(nBytes!=1)
	{
		MessageBox("дBlock 6 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}

	databuff[0]=0x00;databuff[1]=0x00;databuff[2]=0x00;databuff[3]=0x00;
	nBytes = s_t5577_blockWrite(h_Dev,0,0,7,databuff);

	if(nBytes!=1)
	{
		MessageBox("дBlock 7 ����!","����",MB_OK|MB_ICONERROR);
		return;
	}

	nBytes = s_t5577_reset(h_Dev,0,databuff);
	if(nBytes)
	{
		CString str="";
		for(int i=0;i<nBytes;i++)
		{
			str.Format(str+"%2.2X",databuff[i]);
		}
		m_T5557 = str;
		UpdateData(FALSE);
		s_bell(h_Dev,5);
		return;
	}
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
}
