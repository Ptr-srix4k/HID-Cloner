// srf32emidDlg.cpp : implementation file
//

#include "stdafx.h"
#include "srf32emid.h"
#include "srf32emidDlg.h"
#include "SRF32.H"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSrf32emidDlg dialog

CSrf32emidDlg::CSrf32emidDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrf32emidDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSrf32emidDlg)
	m_emid = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrf32emidDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSrf32emidDlg)
	DDX_Text(pDX, IDC_EDIT1, m_emid);
	DDV_MaxChars(pDX, m_emid, 10);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrf32emidDlg, CDialog)
	//{{AFX_MSG_MAP(CSrf32emidDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrf32emidDlg message handlers

BOOL CSrf32emidDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrf32emidDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrf32emidDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

HANDLE h_Dev = NULL;

void CSrf32emidDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	if(s_test_dll(2012)!=2013)
	{
		return;
	}
	h_Dev = s_init(0,NULL,NULL,NULL);
	if (h_Dev == NULL)
	{
		return;
	}
	Sleep(100);
	if(s_test_device(h_Dev,2012)!=2013)
	{
		Sleep(50);
		s_bell(h_Dev,1);
		Sleep(100);
		s_bell(h_Dev,1);
		Sleep(100);
		s_bell(h_Dev,1);
		Sleep(100);
		s_exit(h_Dev);
		h_Dev = NULL;
		return;
	}
	s_bell(h_Dev,5);
}

void CSrf32emidDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	s_exit(h_Dev);
	h_Dev = NULL;
}

void CSrf32emidDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	s_bell(h_Dev,5);
}

void CSrf32emidDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	unsigned char buff[256];
	__int16 st = 0;
	m_emid = "";
	st = s_emid_read(h_Dev,buff);
	if(st==5)
	{
		CString str="";
		for(int i=0;i<st;i++)
		{
			str.Format(str+"%2.2X",buff[i]);
		}
		m_emid = str;
		s_bell(h_Dev,5);
		UpdateData(FALSE);
		return;
	}
	UpdateData(FALSE);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
	Sleep(70);
	s_bell(h_Dev,1);
}
