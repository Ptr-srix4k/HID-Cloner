// srf32emidDlg.h : header file
//

#if !defined(AFX_SRF32EMIDDLG_H__055F06E8_FEBB_472B_A8CB_960C121C73C6__INCLUDED_)
#define AFX_SRF32EMIDDLG_H__055F06E8_FEBB_472B_A8CB_960C121C73C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSrf32emidDlg dialog

class CSrf32emidDlg : public CDialog
{
// Construction
public:
	CSrf32emidDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSrf32emidDlg)
	enum { IDD = IDD_SRF32EMID_DIALOG };
	CString	m_emid;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSrf32emidDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSrf32emidDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRF32EMIDDLG_H__055F06E8_FEBB_472B_A8CB_960C121C73C6__INCLUDED_)
