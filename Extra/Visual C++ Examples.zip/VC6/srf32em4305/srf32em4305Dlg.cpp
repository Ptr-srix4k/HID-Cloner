// srf32em4305Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "srf32em4305.h"
#include "srf32em4305Dlg.h"
#include "SRF32.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSrf32em4305Dlg dialog

CSrf32em4305Dlg::CSrf32em4305Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrf32em4305Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSrf32em4305Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrf32em4305Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSrf32em4305Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrf32em4305Dlg, CDialog)
	//{{AFX_MSG_MAP(CSrf32em4305Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_INIT, OnButtonInit)
	ON_BN_CLICKED(IDC_BUTTON_EXIT, OnButtonExit)
	ON_BN_CLICKED(IDC_BUTTON_BELL, OnButtonBell)
	ON_BN_CLICKED(IDC_BUTTON_LOGIN, OnButtonLogin)
	ON_BN_CLICKED(IDC_BUTTON_BLOCK_READ, OnButtonBlockRead)
	ON_BN_CLICKED(IDC_BUTTON_BLOCK_WRITE, OnButtonBlockWrite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrf32em4305Dlg message handlers

BOOL CSrf32em4305Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrf32em4305Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrf32em4305Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
HANDLE h_Dev = NULL;
void CSrf32em4305Dlg::OnButtonInit() 
{
	// TODO: Add your control notification handler code here
	h_Dev = s_init(0,0,NULL,NULL);
	if (h_Dev == NULL)
	{
		return;
	}
	s_bell(h_Dev,1);
}

void CSrf32em4305Dlg::OnButtonExit() 
{
	// TODO: Add your control notification handler code here
	s_exit(h_Dev);
	h_Dev = NULL;
}

void CSrf32em4305Dlg::OnButtonBell() 
{
	// TODO: Add your control notification handler code here
	if(h_Dev==NULL)
	{
		return;
	}
	s_bell(h_Dev,1);
}

void CSrf32em4305Dlg::OnButtonLogin() 
{
	// TODO: Add your control notification handler code here
	unsigned char databuff[256];
	__int16 nBytes = 0;
	databuff[0] = 0x00;
	databuff[1] = 0x00;
	databuff[2] = 0x00;
	databuff[3] = 0x00;
	nBytes = s_em4305_login(h_Dev,0,databuff);
	if(nBytes==1)
	{
		s_bell(h_Dev,1);
		return;
	}
	s_bell(h_Dev,1);
	Sleep(50);
	s_bell(h_Dev,1);
	Sleep(50);
	s_bell(h_Dev,1);
}

void CSrf32em4305Dlg::OnButtonBlockRead() 
{
	// TODO: Add your control notification handler code here
	CString str="";
	unsigned char databuff[256];
	__int16 nBytes = 0;
	nBytes = s_em4305_readWord(h_Dev,0,1,databuff);
	if(nBytes==4)
	{
		str += "UID: ";
		for(int i =0;i<4;i++)
		{
			str.Format(str+"%2.2X",databuff[i]);
		}
		str += "\r\n";
	}
	nBytes = s_em4305_readWord(h_Dev,0,4,databuff);
	if(nBytes==4)
	{
		str += "Block4: ";
		for(int i =0;i<4;i++)
		{
			str.Format(str+"%2.2X",databuff[i]);
		}
		str += "\r\n";
	}
	nBytes = s_em4305_readWord(h_Dev,0,5,databuff);
	if(nBytes==4)
	{
		str += "Block5: ";
		for(int i =0;i<4;i++)
		{
			str.Format(str+"%2.2X",databuff[i]);
		}
		str += "\r\n";
	}
	nBytes = s_em4305_readWord(h_Dev,0,6,databuff);
	if(nBytes==4)
	{
		str += "Block6: ";
		for(int i =0;i<4;i++)
		{
			str.Format(str+"%2.2X",databuff[i]);
		}
		str += "\r\n";
	}
	MessageBox(str);
}

void CSrf32em4305Dlg::OnButtonBlockWrite() 
{
	// TODO: Add your control notification handler code here
	unsigned char databuff[256];
	__int16 nBytes = 0;
	databuff[0] = 0x00;
	databuff[1] = 0x00;
	databuff[2] = 0x00;
	databuff[3] = 0x00;
	nBytes = s_em4305_writeWord(h_Dev,0,5,databuff);
	if(nBytes==1)
	{
		s_bell(h_Dev,1);
		return;
	}
	s_bell(h_Dev,1);
	Sleep(50);
	s_bell(h_Dev,1);
	Sleep(50);
	s_bell(h_Dev,1);
}
