// stdafx.cpp : source file that includes just the standard includes
//	srf32em4305.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



