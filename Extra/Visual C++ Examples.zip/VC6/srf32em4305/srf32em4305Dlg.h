// srf32em4305Dlg.h : header file
//

#if !defined(AFX_SRF32EM4305DLG_H__80080518_990D_426C_B686_EAADD0159A4D__INCLUDED_)
#define AFX_SRF32EM4305DLG_H__80080518_990D_426C_B686_EAADD0159A4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSrf32em4305Dlg dialog

class CSrf32em4305Dlg : public CDialog
{
// Construction
public:
	CSrf32em4305Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSrf32em4305Dlg)
	enum { IDD = IDD_SRF32EM4305_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSrf32em4305Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSrf32em4305Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonInit();
	afx_msg void OnButtonExit();
	afx_msg void OnButtonBell();
	afx_msg void OnButtonLogin();
	afx_msg void OnButtonBlockRead();
	afx_msg void OnButtonBlockWrite();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRF32EM4305DLG_H__80080518_990D_426C_B686_EAADD0159A4D__INCLUDED_)
